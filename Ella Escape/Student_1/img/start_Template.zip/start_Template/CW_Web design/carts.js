const form = document.getElementById('form');
const fullname = document.getElementById('fname');
const email = document.getElementById('email');
const address = document.getElementById('address');
const city = document.getElementById('city');
const country = document.getElementById('country');
const zipcode = document.getElementById('zipcode');
const cardName = document.getElementById('cardName');
const creditCardNum = document.getElementById('creditCardNum');
const expMonth = document.getElementById('expMonth');
const expYear = document.getElementById('expYear');
const cv = document.getElementById('cv');

//show error function
function showError(input, message){
    const InputBox = input.parentElement;
    InputBox.className = 'inputBox error';
    const small = InputBox.querySelector('small');
    small.innerText = message;
}

//show valid
function showValid(input){
  InputBox = input.parentElement;
  InputBox.className = 'inputBox valid';
}


//Event listeners
form.addEventListener('submit', function (e){
    e.preventDefault();

    //form validation
    if(fullname.value === ''){
        showError(fullname, 'First name is required');
    } else {
        showValid(fullname);
    }

    if(email.value === ''){
      showError(email, 'Email is required');
  } else {
      showValid(email);
  }

    if(address.value === ''){
    showError(address, 'Address is required');
  } else {
    showValid(address);
  }

  if(city.value === ''){
    showError(city, 'City is required');
  } else {
    showValid(city);
  }
  if(country.value === ''){
    showError(country, 'Country is required');
  } else {
    showValid(country);
  }
  if(zipcode.value === ''){
    showError(zipcode, 'ZipCode is required');
  } else {
    showValid(zipcode);
  }
  if(cardName.value === ''){
    showError(cardName, 'Card Name is required');
  } else {
    showValid(cardName);
  }
  if(creditCardNum.value === ''){
    showError(creditCardNum, 'Credit Card Number is required');
  } else {
    showValid(creditCardNum);
  }
  if(expMonth.value === ''){
    showError(expMonth, 'Expirory Month is required');
  } else {
    showValid(expMonth);
  }
  if(expYear.value === ''){
    showError(expYear, 'Expirory Year is required');
  } else {
    showValid(expYear);
  }
  if(cv.value === ''){
    showError(cv, 'CV is required');
  } else {
    showValid(cv);
  }
  if (true) {
    var modal = document.getElementById("myModal");
    var span = document.getElementsByClassName("close")[0];

    modal.style.display = "block";

    span.onclick = function () {
        modal.style.display = "none";
    }

    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
      }
  }

return false;

//if form is valid, submit the form
form.submit();
})

//Show done screen
function paymentDone (){
  var modal = document.getElementById("myModal");
  modal.style.display = "none";

  var donemodal = document.getElementById("doneModal");

  donemodal.style.display = "block";

  setTimeout(function(){
      donemodal.style.display = "block";
      window.location.href = 'shop.html';}, 2200);
  localStorage.clear();
  return false;
}
//Inputs empty validation
function formValidation(){

  var f = document.getElementById('fname').value;
  var l = document.getElementById('lname').value;
  var e = document.getElementById('email').value;
  var m = document.getElementById('mnum').value;
  var a = document.getElementById('address').value;
  var c = document.getElementById('city').value;
  var co = document.getElementById('country').value;
  var zip = document.getElementById('zipcode').value;

  let productNumbers = localStorage.getItem('cartNumbers');

  if (productNumbers == 0 || productNumbers == null){
      alert('Cart Empty, please add one or more items from shop!');
      return false;
  }

  if (f == '' || f == null || l == '' || l == null || e == '' || e == null || m == '' || m == null || a == '' || a == null || c == '' || c == null || co == '' || co == null || zip == '' || zip == null){
      alert('Please fill all the fields to continue!');
      return false;
  } else {
      
      let userName = document.getElementById('fname').value;
          
      if (userName){
          document.querySelector('.userName').textContent = userName; 
      };
      
      if (f){
          document.querySelector('.fname-span').textContent = f; 
      };

      if (l){
          document.querySelector('.lname-span').textContent = l; 
      };

      if (m){
          document.querySelector('.mnum-span').textContent = m; 
      };

      if (e){
          document.querySelector('.email-span').textContent = e; 
      };

      if (a){
          document.querySelector('.address-span').textContent = a; 
      };

      if (c){
          document.querySelector('.city-span').textContent = c; 
      };

      if (co){
          document.querySelector('.country-span').textContent = co; 
      };

      if (zip){
          document.querySelector('.zip-span').textContent = zip; 
      };

      if (true) {
          var modal = document.getElementById("myModal");
          var span = document.getElementsByClassName("close")[0];

          modal.style.display = "block";

          span.onclick = function () {
              modal.style.display = "none";
          }

          window.onclick = function (event) {
              if (event.target == modal) {
                  modal.style.display = "none";
              }
          }
      }
      
      return false;  
  }
}
function displayCartModal() {
  let cartItems = localStorage.getItem("productsInCart");
  cartItems = JSON.parse(cartItems);
  let cartCost = localStorage.getItem('totalCost');

  let productContainer = document.querySelector(".modal-cart-products")
  if(cartItems && productContainer) {
      productContainer.innerHTML = '';
      Object.values(cartItems).map(item => {
          productContainer.innerHTML += `
          <div class="cart-product-title">
              <div class="product-img">
                  <img src ="img/product-images/${item.tag}.png">
              </div>
              <span>${item.name}</span>
          </div>
          <div class="cart-product-price">$${item.price}.00</div>
          <div class="cart-quantity">
              <span>${item.inCart}</span>
          </div>
          <div class="cart-total">
              $${item.inCart * item.price}.00
          </div>
          `;
      });

      productContainer.innerHTML += `
            <div class="basketTotalContainer">
                <h2 class="basketTotalTitle">
                Total Cost
                </h2>
                <h2 class="basketTotal">
                    $${cartCost}.00
                </h2>
            </div>
        `;
    }
}

