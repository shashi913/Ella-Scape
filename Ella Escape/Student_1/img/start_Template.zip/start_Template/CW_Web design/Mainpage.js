const activePage = window.location.pathname;
const navLinks = document.querySelectorAll(".option");
